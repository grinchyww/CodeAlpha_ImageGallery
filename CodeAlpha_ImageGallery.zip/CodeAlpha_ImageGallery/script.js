// Contact Sheets — CodeAlpha Frontend Task 1
// A darkroom-style image gallery: film strips, grease-pencil picks,
// and a light table with a loupe. Photos come from picsum.photos.

const ROLLS = [
  {
    key: 'nature', name: 'Landscapes', frames: [
      { id: 1015, title: 'River valley' },
      { id: 1018, title: 'Mountain ridge' },
      { id: 1016, title: 'Canyon walls' },
      { id: 1036, title: 'Winter forest' },
    ],
  },
  {
    key: 'city', name: 'City', frames: [
      { id: 1031, title: 'Tall buildings' },
      { id: 1067, title: 'City street' },
      { id: 1044, title: 'Evening light' },
      { id: 1076, title: 'Downtown' },
    ],
  },
  {
    key: 'animals', name: 'Animals', frames: [
      { id: 1025, title: 'Pug in a blanket' },
      { id: 1024, title: 'Watchful bird' },
      { id: 1074, title: 'Resting lion' },
      { id: 237, title: 'Puppy' },
    ],
  },
];

const imgUrl = (id, w, h) => `https://picsum.photos/id/${id}/${w}/${h}`;

// Flatten into one list of photos with roll + frame numbers
const ALL = ROLLS.flatMap((roll, r) =>
  roll.frames.map((f, i) => ({ ...f, roll: roll.key, rollName: roll.name, rollNo: r + 1, frameNo: i + 1 }))
);

const $ = id => document.getElementById(id);
const sheet = $('sheet');
const filterNav = $('rollFilter');
const pickCount = $('pickCount');
const table = $('table');
const printFig = $('print');
const printImg = $('printImg');
const printTitle = $('printTitle');
const loupe = $('loupe');
const loupeBtn = $('loupeBtn');
const pickBtn = $('pickBtn');
const mini = $('mini');
const toning = $('toning');

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const coarsePointer = window.matchMedia('(pointer: coarse)').matches;

let visible = [...ALL];
let current = 0;
let loupeOn = !coarsePointer;
let lastFocus = null;

/* ---------- Picks (saved in the browser) ---------- */
let picks = new Set();
try { picks = new Set(JSON.parse(localStorage.getItem('contact-sheet-picks') || '[]')); } catch { /* storage blocked */ }

function savePicks() {
  try { localStorage.setItem('contact-sheet-picks', JSON.stringify([...picks])); } catch { /* storage blocked */ }
  updatePickCount();
}

function updatePickCount() {
  const n = picks.size;
  pickCount.textContent = n === 0
    ? 'No picks yet. Open a frame and mark the ones you like.'
    : `${n} ${n === 1 ? 'frame' : 'frames'} circled as picks.`;
}

/* ---------- Contact sheet ---------- */
const WAX = `<svg class="wax" viewBox="0 0 100 66" preserveAspectRatio="none" aria-hidden="true">
  <path pathLength="1" d="M52 5 C 82 3, 97 17, 95 34 C 93 55, 70 63, 46 62 C 19 61, 3 49, 5 31 C 7 14, 27 5, 60 7"/>
</svg>`;

function renderSheet(filter = 'all') {
  visible = filter === 'all' ? [...ALL] : ALL.filter(p => p.roll === filter);
  sheet.innerHTML = '';

  ROLLS.forEach((roll, r) => {
    if (filter !== 'all' && roll.key !== filter) return;

    const section = document.createElement('section');
    section.className = 'roll';
    const label = document.createElement('h2');
    label.className = 'roll-label';
    label.textContent = `Roll ${r + 1}: ${roll.name}`;

    const scroller = document.createElement('div');
    scroller.className = 'strip-scroll';
    const strip = document.createElement('ul');
    strip.className = 'strip';

    ALL.filter(p => p.roll === roll.key).forEach(photo => {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.className = 'frame' + (picks.has(photo.id) ? ' picked' : '');
      btn.dataset.id = photo.id;
      btn.setAttribute('aria-label', `${photo.title}, roll ${photo.rollNo} frame ${photo.frameNo}`);
      btn.innerHTML = `
        <span class="edge" aria-hidden="true"><span>▸${photo.frameNo}</span><span>${photo.frameNo}A</span></span>
        <span class="neg"><img src="${imgUrl(photo.id, 480, 320)}" alt="" loading="lazy"></span>
        ${WAX}`;
      btn.addEventListener('click', () => openTable(visible.indexOf(photo), btn));
      li.appendChild(btn);
      strip.appendChild(li);
    });

    scroller.appendChild(strip);
    section.append(label, scroller);
    sheet.appendChild(section);
  });
}

filterNav.addEventListener('click', e => {
  const btn = e.target.closest('.roll-btn');
  if (!btn) return;
  filterNav.querySelectorAll('.roll-btn').forEach(b => b.setAttribute('aria-pressed', String(b === btn)));
  renderSheet(btn.dataset.filter);
});

/* ---------- Light table ---------- */
function renderMini() {
  mini.innerHTML = '';
  visible.forEach((photo, i) => {
    const b = document.createElement('button');
    b.setAttribute('aria-label', photo.title);
    b.innerHTML = `<img src="${imgUrl(photo.id, 132, 88)}" alt="" loading="lazy">`;
    b.addEventListener('click', () => showFrame(i));
    mini.appendChild(b);
  });
}

function showFrame(i) {
  current = (i + visible.length) % visible.length;
  const photo = visible[current];

  // "Develop" the print each time it changes
  printFig.classList.remove('developing');
  void printFig.offsetWidth;
  if (!reduceMotion) printFig.classList.add('developing');

  printImg.src = imgUrl(photo.id, 1500, 1000);
  printImg.alt = photo.title;
  loupe.style.backgroundImage = `url("${printImg.src}")`;

  printTitle.textContent = photo.title;
  const sub = document.createElement('span');
  sub.textContent = `Roll ${photo.rollNo}, frame ${photo.frameNo}`;
  printTitle.appendChild(sub);

  const picked = picks.has(photo.id);
  pickBtn.setAttribute('aria-pressed', String(picked));
  pickBtn.textContent = picked ? 'Picked' : 'Mark as pick';

  [...mini.children].forEach((b, j) => {
    b.setAttribute('aria-current', String(j === current));
    if (j === current) b.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  });
}

function openTable(i, opener) {
  lastFocus = opener || document.activeElement;
  renderMini();
  showFrame(i);
  table.classList.add('open');
  table.setAttribute('aria-hidden', 'false');
  if (!reduceMotion) {
    table.classList.remove('flicker');
    void table.offsetWidth;
    table.classList.add('flicker');
  }
  document.body.style.overflow = 'hidden';
  $('closeTable').focus();
}

function closeTable() {
  table.classList.remove('open', 'flicker');
  table.setAttribute('aria-hidden', 'true');
  loupe.classList.remove('show');
  document.body.style.overflow = '';
  if (lastFocus) lastFocus.focus();
}

const nextFrame = () => showFrame(current + 1);
const prevFrame = () => showFrame(current - 1);

$('nextFrame').addEventListener('click', nextFrame);
$('prevFrame').addEventListener('click', prevFrame);
$('closeTable').addEventListener('click', closeTable);

/* ---------- Picks ---------- */
function togglePick() {
  const photo = visible[current];
  if (picks.has(photo.id)) picks.delete(photo.id);
  else picks.add(photo.id);
  savePicks();
  showFrame(current);
  const frameBtn = sheet.querySelector(`.frame[data-id="${photo.id}"]`);
  if (frameBtn) frameBtn.classList.toggle('picked', picks.has(photo.id));
}
pickBtn.addEventListener('click', togglePick);

/* ---------- Loupe ---------- */
const ZOOM = 2.6;

function setLoupe(on) {
  loupeOn = on;
  loupeBtn.setAttribute('aria-pressed', String(on));
  if (!on) loupe.classList.remove('show');
  printImg.style.cursor = on ? 'crosshair' : 'default';
}

if (coarsePointer) loupeBtn.hidden = true;
loupeBtn.addEventListener('click', () => setLoupe(!loupeOn));

printImg.addEventListener('pointermove', e => {
  if (!loupeOn || e.pointerType === 'touch') return;
  const img = printImg.getBoundingClientRect();
  const fig = printFig.getBoundingClientRect();
  const x = e.clientX - img.left;
  const y = e.clientY - img.top;
  const r = loupe.clientWidth / 2;

  loupe.style.left = `${e.clientX - fig.left}px`;
  loupe.style.top = `${e.clientY - fig.top}px`;
  loupe.style.backgroundSize = `${img.width * ZOOM}px ${img.height * ZOOM}px`;
  loupe.style.backgroundPosition = `${-(x * ZOOM - r)}px ${-(y * ZOOM - r)}px`;
  loupe.classList.add('show');
});
printImg.addEventListener('pointerleave', () => loupe.classList.remove('show'));

/* ---------- Toning (image filters) ---------- */
toning.addEventListener('click', e => {
  const btn = e.target.closest('button');
  if (!btn) return;
  toning.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b === btn)));
  printFig.style.setProperty('--tone', btn.dataset.tone);
  loupe.style.filter = btn.dataset.tone;
});

/* ---------- Keyboard, swipe, focus ---------- */
document.addEventListener('keydown', e => {
  if (!table.classList.contains('open')) return;
  if (e.key === 'ArrowRight') nextFrame();
  else if (e.key === 'ArrowLeft') prevFrame();
  else if (e.key === 'Escape') closeTable();
  else if (e.key === 'p' || e.key === 'P') togglePick();
  else if ((e.key === 'l' || e.key === 'L') && !coarsePointer) setLoupe(!loupeOn);
  else if (e.key === 'Tab') {
    // keep focus inside the light table
    const focusable = [...table.querySelectorAll('button:not([hidden])')];
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
});

let touchX = 0;
const stage = $('stage');
stage.addEventListener('touchstart', e => { touchX = e.changedTouches[0].clientX; }, { passive: true });
stage.addEventListener('touchend', e => {
  const dx = e.changedTouches[0].clientX - touchX;
  if (Math.abs(dx) > 50) (dx < 0 ? nextFrame : prevFrame)();
});

/* ---------- Start ---------- */
setLoupe(loupeOn);
updatePickCount();
renderSheet();
