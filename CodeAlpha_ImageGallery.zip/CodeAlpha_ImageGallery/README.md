# CodeAlpha_ImageGallery: Contact Sheets

An image gallery designed like a photographer's darkroom. Photos sit on film strips under a red safelight, and opening one places it on a light table. Task 1 of the CodeAlpha Frontend Development internship.

## Features
- Film-strip layout with sprocket holes and frame numbers along the edge
- Hover effect: a yellow grease-pencil circle draws itself around the frame
- **Light table (lightbox):** the light flickers on, and the print develops from black
- Next/previous buttons, a thumbnail strip, arrow keys, and swipe on touch screens
- Responsive from phone to desktop

### Bonus
- **Categories:** filter by roll (Landscapes, City, Animals)
- **Image filters as print toning:** Untoned, Selenium, Sepia, Cyanotype
- **Loupe:** a magnifying glass follows your mouse over the print
- **Picks:** circle your favourite frames. Picks are saved in your browser.
- Keyboard: `←` `→` change frames, `P` marks a pick, `L` toggles the loupe, `Esc` closes

## Run locally
Open `index.html` in a browser. An internet connection is needed because the sample photos come from [picsum.photos](https://picsum.photos).

## Use your own photos
Put your images in an `images/` folder and change `imgUrl()` in `script.js` to return your file paths.

## Tech
HTML5, CSS3 (flexbox, animations, SVG stroke animation), vanilla JavaScript, localStorage.
